export default class Category {
    constructor(id,title,color){
        this.title = title
        this.id = id
        this.color = color
    }
}